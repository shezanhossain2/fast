from pkgutil import extend_path
__path__=extend_path(__path__,__name__)
__version__="2.15.8"
__author__="Ansible, Inc."
