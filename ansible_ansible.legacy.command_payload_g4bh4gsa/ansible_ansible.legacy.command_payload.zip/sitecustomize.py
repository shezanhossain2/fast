import sys
sys.path.insert(0,"/tmp/ansible_ansible.legacy.command_payload_g4bh4gsa/ansible_ansible.legacy.command_payload.zip")
